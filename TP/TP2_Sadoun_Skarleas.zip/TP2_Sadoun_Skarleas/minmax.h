#ifndef H_MINMAX
#define H_MINMAX

void get_min_max_1(int* tab, int n, int* min, int* max);

void get_min_max_rec(int* tab, int from, int to, int* min, int * max);	

void get_min_max_2(int* tab, int n, int* min, int* max);

#endif